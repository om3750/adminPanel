// const BaseURL = "http://192.168.0.107:8080/api/";
const BaseURL = "http://192.168.29.222:8080/api/";

export default BaseURL;
